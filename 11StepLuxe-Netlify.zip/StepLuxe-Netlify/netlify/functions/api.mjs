import { getStore } from '@netlify/blobs';
import crypto from 'node:crypto';

const productsStore = getStore({ name: 'stepluxe-products', consistency: 'strong' });
const ordersStore = getStore({ name: 'stepluxe-orders', consistency: 'strong' });
const imagesStore = getStore({ name: 'stepluxe-images', consistency: 'strong' });

const json = (data, status = 200, extra = {}) => new Response(JSON.stringify(data), {
  status,
  headers: { 'content-type': 'application/json; charset=utf-8', ...extra }
});

function secret() {
  return process.env.SESSION_SECRET || 'CHANGE_THIS_SESSION_SECRET';
}
function sign(value) {
  return crypto.createHmac('sha256', secret()).update(value).digest('hex');
}
function makeSession() {
  const value = `${Date.now()}.${crypto.randomBytes(18).toString('hex')}`;
  return `${value}.${sign(value)}`;
}
function validSession(req) {
  const cookie = req.headers.get('cookie') || '';
  const match = cookie.match(/stepluxe_session=([^;]+)/);
  if (!match) return false;
  const parts = decodeURIComponent(match[1]).split('.');
  if (parts.length !== 3) return false;
  const [time, nonce, sig] = parts;
  if (Date.now() - Number(time) > 1000 * 60 * 60 * 24 * 7) return false;
  const expected = sign(`${time}.${nonce}`);
  return crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected));
}
function requireAuth(req) { return validSession(req); }

async function getProducts() {
  return (await productsStore.get('all', { type: 'json' })) || [];
}
async function saveProducts(products) {
  await productsStore.setJSON('all', products);
}
async function getOrders() {
  return (await ordersStore.get('all', { type: 'json' })) || [];
}
async function saveOrders(orders) {
  await ordersStore.setJSON('all', orders);
}

function cleanName(name='') { return String(name).replace(/[^a-zA-Z0-9._-]/g, '-').slice(0, 80); }

export default async (req) => {
  const url = new URL(req.url);
  const path = url.pathname.replace(/^\/\.netlify\/functions\/api/, '').replace(/^\/api/, '') || '/';

  try {
    if (req.method === 'GET' && path === '/products') {
      const products = (await getProducts()).filter(p => p.active !== false).sort((a,b) => new Date(b.created_at)-new Date(a.created_at));
      return json({ products });
    }

    if (req.method === 'POST' && path === '/login') {
      const body = await req.json();
      const password = String(body.password || '');
      if (!process.env.ADMIN_PASSWORD || password !== process.env.ADMIN_PASSWORD) return json({ error: 'Pogrešna lozinka.' }, 401);
      const session = makeSession();
      return json({ ok: true }, 200, {
        'set-cookie': `stepluxe_session=${encodeURIComponent(session)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=604800`
      });
    }

    if (req.method === 'POST' && path === '/logout') {
      return json({ ok: true }, 200, { 'set-cookie': 'stepluxe_session=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0' });
    }

    if (req.method === 'GET' && path === '/auth') return json({ authenticated: validSession(req) });

    if (path === '/admin/products' && req.method === 'GET') {
      if (!requireAuth(req)) return json({ error: 'Nisi prijavljen.' }, 401);
      return json({ products: await getProducts() });
    }

    if (path === '/admin/product' && req.method === 'POST') {
      if (!requireAuth(req)) return json({ error: 'Nisi prijavljen.' }, 401);
      const body = await req.json();
      if (!body.name || !Number.isFinite(Number(body.price)) || !Array.isArray(body.sizes) || !body.image?.data) return json({ error: 'Popuni naziv, cenu, veličine i sliku.' }, 400);
      const imageId = crypto.randomUUID();
      const mime = String(body.image.mime || 'image/jpeg');
      const raw = String(body.image.data).replace(/^data:[^;]+;base64,/, '');
      const bytes = Buffer.from(raw, 'base64');
      if (bytes.byteLength > 4_500_000) return json({ error: 'Slika je prevelika. Izaberi manju sliku (do oko 4.5 MB).' }, 400);
      await imagesStore.set(`image/${imageId}`, bytes, { metadata: { contentType: mime, filename: cleanName(body.image.name || 'image') } });
      const products = await getProducts();
      const product = {
        id: crypto.randomUUID(), name: String(body.name).trim(), price: Number(body.price),
        sizes: body.sizes.map(x => String(x).trim()).filter(Boolean), description: String(body.description || '').trim(),
        image: `/.netlify/functions/api/image/${imageId}`, imageId, active: true, created_at: new Date().toISOString()
      };
      products.unshift(product); await saveProducts(products);
      return json({ product });
    }

    if (path.startsWith('/admin/product/') && req.method === 'DELETE') {
      if (!requireAuth(req)) return json({ error: 'Nisi prijavljen.' }, 401);
      const id = path.split('/').pop(); const products = await getProducts();
      const product = products.find(p => p.id === id);
      if (!product) return json({ error: 'Proizvod nije pronađen.' }, 404);
      await saveProducts(products.filter(p => p.id !== id));
      if (product.imageId) await imagesStore.delete(`image/${product.imageId}`);
      return json({ ok: true });
    }

    if (path.startsWith('/admin/product/') && req.method === 'PATCH') {
      if (!requireAuth(req)) return json({ error: 'Nisi prijavljen.' }, 401);
      const id = path.split('/').pop(); const body = await req.json(); const products = await getProducts();
      const i = products.findIndex(p => p.id === id); if (i < 0) return json({ error: 'Proizvod nije pronađen.' }, 404);
      products[i] = { ...products[i], ...body, id, price: Number(body.price ?? products[i].price) };
      await saveProducts(products); return json({ product: products[i] });
    }

    if (path === '/order' && req.method === 'POST') {
      const body = await req.json();
      if (!body.customer_name || !body.phone || !body.city || !body.address || !Array.isArray(body.items) || !body.items.length) return json({ error: 'Nedostaju podaci za porudžbinu.' }, 400);
      const orders = await getOrders();
      const order = { id: crypto.randomUUID(), created_at: new Date().toISOString(), status: 'new', customer_name: String(body.customer_name), phone: String(body.phone), city: String(body.city), address: String(body.address), note: String(body.note || ''), items: body.items, total: Number(body.total || 0) };
      orders.unshift(order); await saveOrders(orders); return json({ ok: true, orderId: order.id });
    }

    if (path === '/admin/orders' && req.method === 'GET') {
      if (!requireAuth(req)) return json({ error: 'Nisi prijavljen.' }, 401);
      return json({ orders: await getOrders() });
    }

    if (path.startsWith('/admin/order/') && req.method === 'PATCH') {
      if (!requireAuth(req)) return json({ error: 'Nisi prijavljen.' }, 401);
      const id = path.split('/').pop(); const body = await req.json(); const orders = await getOrders();
      const i = orders.findIndex(o => o.id === id); if (i < 0) return json({ error: 'Porudžbina nije pronađena.' }, 404);
      orders[i].status = String(body.status || orders[i].status); await saveOrders(orders); return json({ order: orders[i] });
    }

    if (req.method === 'GET' && path.startsWith('/image/')) {
      const id = path.split('/').pop(); const result = await imagesStore.getWithMetadata(`image/${id}`, { type: 'arrayBuffer' });
      if (!result) return new Response('Not found', { status: 404 });
      return new Response(result.data, { headers: { 'content-type': result.metadata?.contentType || 'image/jpeg', 'cache-control': 'public, max-age=31536000, immutable' } });
    }

    return json({ error: 'Not found' }, 404);
  } catch (e) {
    console.error(e); return json({ error: 'Greška servera.' }, 500);
  }
};
